package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		AccountService service=new AccountServiceImpl();
		System.out.println("1 Account Balance Enquiry ");
		System.out.println("2 Recharge Account");
		System.out.println("3 Exit");
		int choice=sc.nextInt();
		Account acc;
		
		switch(choice) 
		{
		case 1:
		System.out.println("Enter the mobile no");
		String mobileNo=sc.next();
		acc=service.getAccountDetails(mobileNo);
			System.out.println("Bal is "+acc.getAccountbalance());
		break;
		case 2:
			System.out.println("Enter the mobile no");
			String mobileNo1=sc.next();
			System.out.println("Enter the amount");
			double rechargeAmount=sc.nextDouble();
			double newbal=service.rechargeAccount(mobileNo1, rechargeAmount);
			System.out.println("The updated bal is "+newbal);
			break;
		case 3:
			System.out.println("Exit");
			System.exit(0);
			break;
	
		
		
		
		}
		System.out.println("What do you want to do now");
		System.out.println("1 Continue \n 2 Exit");
		int select=sc.nextInt();
		if(select==2)
			System.exit(0);
		main(null);
	}
		

	}


